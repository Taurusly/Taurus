
;(function(){
$('.mui-pull-left').on('tap',function(){
   api.closeWin()
})
$('.mycitys').on('tap',function(){
  //  api.closeWin()
  api.sendEvent({
      name: 'foots',
      extra: {
          key1: 'value1',
          key2: 'value2'
      }
  });
})
$(document).on('tap','.mui-icon-back',function(){
   api.closeWin()
});
// 认证失败 跳到登陆页
$(document).on('authFailed', function(){
    api.openWin({
        name: 'login',
        // url: 'html/login.html',
        url: 'widget://html/login.html',
        rect: {
            x: 0,
            y: 0,
            w: 'auto',
            h: api.winHeight
        },
        bounces: false,
        slidBackEnabled:false,
        vScrollBarEnabled: false,
        hScrollBarEnabled: false
    })
})

  window.app={
    //微信分享略缩图
    wxImg : 'widget://image/2018119.png',
    // 头部高度
    headerHeight: 45,
    // 搜索框 高度
    searchBarHeight: 50,
    // server  : 'http://heilgo.cn/redpaper/open/api/',            //----------------------------------------
    server  : 'http://un369.cn/redpaper/open/api/',          //
    memberId: $api.getStorage('memberId'),
    token   : $api.getStorage('token'),
    // 需要调用到api的方法或属性的一些公共操作
    ready : function(){
      // 全局的加载控件
        window.loading = api.require('UILoading')
        app.windowHeight = api.winHeight
    },

    // toast 提示``
    toast: function(msg){
        api.toast({
            msg: msg,
            duration: 1200,
            location: 'middle'
        })
    },


    // confirm 确定
    confirm: function(msg, sureCb, cancleCb){
      api.confirm({
          title: '提示',
          msg: msg,
          buttons: ['确定', '取消']
      }, function(ret, err){
          if( ret ){
               sureCb && sureCb()
          }else{
               cancleCb && cancleCb()
          }
      })
    },
    // ajax请求封装
    ajax: function(params){
      $.ajax({
        type: params.type || 'POST',
        url :  app.server + params.url,
        data: params.data,
        dataType: 'json',
        timeout: params.timeout || 50000,
        async:false,
        beforeSend: function(){
          if(params.showLoading == true) {
              app.loading()
          }else{
              app.closeLoading()
          }
        },
        success: function(data){
          if(params.callback) {
            params.callback(data)
          } else if(params.success){
            app.closeLoading(function(){
              // 请求正常
              if(data.code == 0) {
                params.success(data)
              } else {
                app.toast(data.msg)
                app.closeLoading()
                api.refreshHeaderLoadDone()
                if(data.code == -1 || data.code == -2) {
                  $(document).trigger('authFailed') // 触发认证失败事件
                }
              }
            })
          }
        },
        error: function(xhr, type){
          app.closeLoading()
          api.refreshHeaderLoadDone()
          app.toast('网络异常!')
        }
      })
    },
    // 关闭加载样式
    closeLoading : function(cb){
      setTimeout(function(){
        if(window.loading){
          window.loading.closeKeyFrame()
          window.loading.status = ''
        }
        cb && cb()
      }, app.loading.timeStamp - Date.now() + 500);
    },
    // 打开加载样式
    loading : function(){
        window.loading = api.require('UILoading')
      this.loading.timeStamp = Date.now()
      window.loading && window.loading.status !== 'active' && window.loading.keyFrame({
          rect: {
              w: 80,
              h: 80
          },
          styles: {
              // bg: 'rgb(219,61,9)',
              bg: 'rgb(0,0,0,0.5)',
              corner: 5,
              interval: 60,
              frame: {
                  w: 80,
                  h: 80
              }
          }
      }, function(ret) {
        window.loading.status = 'active'
      })
    },
    ajaxWithLoadMore: function(params) {
      var _params
      var fn = function(){
          if(fn.status !== 'NOMORE') {
            app.ajax(_params)
          }
      }
      fn.init = function(){
        _params   = $.extend({}, params)
        fn.status = 'REFRESH'
        if(!_params.data) _params.data = {}
        _params.data.pageSize = 10
        _params.data.pageNum  = 1
        $('.load-more').html('<span style="background:url(/../image/me/loading.gif) no-repeat; width:22px;height:22px;background-size:22px;vertical-align:middle;display:inline-block;margin-right:5px;"></span>上拉加载更多')
        $('.load-moreConvert').html('<span style="background:url(../../../../../image/me/loading.gif) no-repeat; width:22px;height:22px;background-size:22px;vertical-align:middle;display:inline-block;margin-right:5px;text-align:center;"></span>上拉加载更多')
        $('.load-moreCity').html('<span style="background:url(../../../../../../image/me/loading.gif) no-repeat; width:22px;height:22px;background-size:22px;vertical-align:middle;display:inline-block;text-align:center;margin-right:5px;"></span>上拉加载更多')
        if(params.success) {
          _params.success = function(rst){
            params.success(rst)
            _params.data.pageNum++
            // console.log('rst.data.length='+rst.data.length)
            // console.log('_params.data.pageSize='+_params.data.pageSize)
            if(rst.data.length <_params.data.pageSize) {
              fn.status = "NOMORE"
              $('.load-more').text('暂无更多数据')
              $('.load-moreConvert').text('暂无更多数据')
              $('.load-moreCity').text('暂无更多数据')
            } else {
              fn.status = 'DATA'
              // $('.load-mores').text('暂无更多数据')
            }
          }
        }
        return fn
      }
      fn.init()
      return fn
    },
    ajaxWithLoadMoreXian: function(params) {
      var _params
      var fn = function(){
          if(fn.status !== 'NOMORE') {
            app.ajax(_params)
          }
      }
      fn.init = function(){
        _params   = $.extend({}, params)
        fn.status = 'REFRESH'
        if(!_params.data) _params.data = {}
        _params.data.pageSize = 10
        _params.data.pageNum  = 1
        $('.load-more').html('<span style="background:url(../../../../../image/me/loading.gif) no-repeat; width:22px;height:22px;background-size:22px;vertical-align:middle;display:inline-block;margin-right:5px;"></span>上拉加载更多')
        $('.load-moreConvert').html('<span style="background:url(../../../../../image/me/loading.gif) no-repeat; width:22px;height:22px;background-size:22px;vertical-align:middle;display:inline-block;margin-right:5px;"></span>上拉加载更多')
        if(params.success) {
          _params.success = function(rst){
            params.success(rst)
            _params.data.pageNum++
            console.log('rst.data.length='+rst.data.histories.length)
            console.log('_params.data.pageSize='+_params.data.pageSize)
            if(rst.data.histories.length <_params.data.pageSize) {
              fn.status = "NOMORE"
              $('.load-more').text('暂无更多数据')
              $('.load-moreConvert').text('暂无更多数据')
            } else {
              fn.status = 'DATA'
              // $('.load-mores').text('暂无更多数据')
            }
          }
        }
        return fn
      }
      fn.init()
      return fn
    },
    ajaxWithLoadMoreDetail: function(params) {
      var _params
      var fn = function(){
          if(fn.status !== 'NOMORE') {
            app.ajax(_params)
          }
      }
      fn.init = function(){
        _params   = $.extend({}, params)
        fn.status = 'REFRESH'
        if(!_params.data) _params.data = {}
        _params.data.pageSize = 10
        _params.data.pageNum  = 1
        $('.load-moreConvert').html('<span style="background:url(../../../../../image/me/loading.gif) no-repeat; width:22px;height:22px;background-size:22px;vertical-align:middle;display:inline-block;margin-right:5px;"></span>上拉加载更多')
        if(params.success) {
          _params.success = function(rst){
            params.success(rst)
            _params.data.pageNum++
            // console.log('rst.data.length='+rst.data.details.length)
            // console.log('_params.data.pageSize='+_params.data.pageSize)
            if(rst.data.length <_params.data.pageSize) {
              fn.status = "NOMORE"
              $('.load-moreConvert').text('暂无更多数据')
            } else {
              fn.status = 'DATA'
              // $('.load-mores').text('暂无更多数据')
            }
          }
        }
        return fn
      }
      fn.init()
      return fn
    },
 ajaxWithLoadMorePush: function(params) {
  var _params
  var fn = function(){
      if(fn.status !== 'NOMORE') {
        app.ajax(_params)
      }
  }
  fn.init = function(){
    _params   = $.extend({}, params)
    fn.status = 'REFRESH'
    if(!_params.data) _params.data = {}
    _params.data.pageSize = 10
    _params.data.pageNum  = 1
    $('.load-more').html('<span style="background:url(../../../../../image/loading.gif) no-repeat; width:22px;height:22px;background-size:22px;vertical-align:middle;display:inline-block;margin-right:5px;"></span>上拉加载更多...')
    // $('.load-more').html('加载更多...')
    if(params.success) {
      _params.success = function(rst){
        params.success(rst)
        _params.data.pageNum++
        console.log('--------------rst.data.length='+rst.data.data.length)
        console.log('---------------_params.data.pageSize='+_params.data.pageSize)
        if(rst.data.data.length < _params.data.pageSize) {
          fn.status = 'NOMORE'
          $('.load-more').text('暂无更多数据')
        } else {
          fn.status = "DATA"
        }
      }
    }
    return fn
  }
  fn.init()
  return fn
},
    players:function(player,box){
        mui('body').on('tap',player,function(e){
          var e = e || window.event;
          var elem = e.target || e.srcElement;
          while (elem) {
                      if (elem.id && elem.id ===box) {
                          return
                      }
                      elem = elem.parentNode;
                  }
            $(player).hide()
        })
    },
    //跳转--------------------
    openFrames:function(x,y,w,h,urlA){
      api.openFrame({
          name: 'urlA',
          url: urlA,
          rect: {
              x: x,
              y: y,
              w: w,
              h: h
          },
          pageParam: {
              name: 'test'
          },
          bounces: true,
          // bgColor: '#74481C',
          bgColor: 'rgba(0,0,0,0)',
          slidBackEnabled:false,
          vScrollBarEnabled: true,
          hScrollBarEnabled: true
      });
    },
    //prevent multiple pull up
throttle:function(){
  var isClear = arguments[0],fn;
  if(typeof isClear === "boolean"){
      fn=arguments[1];
      fn._throttleID && clearTimeout(fn._throttleID);
  }else{
      fn=isClear;
      param=arguments[1];
      var p={
          context:null,
          args:[],
          time:1000
      }
      arguments.callee(true,fn);
      fn._throttleID=setTimeout(function(){
          fn.apply(p.context,p.args)
      },p.time)
    }
  },
  startTime:function(timestamp){
      var date = new Date(timestamp * 1000);//时间戳为10位需*1000，时间戳为13位的话不需乘1000
          Y = date.getFullYear() + '-';
          M = (date.getMonth()+1 < 10 ? '0'+(date.getMonth()+1) : date.getMonth()+1) + '-';
          D = date.getDate() + ' ';
          h = date.getHours() + ':';
          m = date.getMinutes() ;
          return Y+M+D+h+m;
  },
  totalCount:function(){
      app.ajax({
         url:'message/getAllMessageCount',
         type:'GET',
         data:{
           memberId:$api.getStorage('memberId'),
           token:$api.getStorage('token')
         },
         success:function(data){
            // alert('====================================='+JSON.stringify(data))
            if(data.data.data.allMessageCount>0){
              $('#headSpan').append('<span class="count">'+data.data.data.allMessageCount+'</span>')
            }
         }
      })
  },
  // balance
  balance:function(){
     app.ajax({
         url:'memberaccount/getMyAccount',
         data:{
           memberId:$api.getStorage('memberId'),
           token:$api.getStorage('token')
         },
         success:function(data){
             console.log(JSON.stringify(data))
             $('.balance b').html(data.data.amount)
             $('.redvalue').html(data.data.redvalue)
         }
     })
  },
  gem:function(){
     app.ajax({
        url:'exchange/goods/getMemberStoreAccount',
        data:{
          memberId:$api.getStorage('memberId'),
          token:$api.getStorage('token')
        },
        success:function(data){
            console.log(JSON.stringify(data)+'------------')
            $('.a').html('<i></i>'+data.data.greenStone)
            $('.b').html('<i></i>'+data.data.yellowStone)
            $('.c').html('<i></i>'+data.data.redStone)
        }
     })
  },
  cityNums:function(){
    app.ajax({
       url:'arealord/ticket/myCitySaleNum',
       data:{
         memberId:$api.getStorage('memberId'),
         token:$api.getStorage('token')
       },
       success:function(data){
           $('.saleCount b').html(data.data.ableCount)
           $('.ableCount b').html(data.data.saleCount)
           $('.openCount b').html(data.data.openCount)
       }
    })
  },
  touchs:function(){
  var expansion = null;
  var container = document.querySelectorAll('.boxs li');
  for (var i = 0; i < container.length; i++) {
      var x, y, X, Y, swipeX, swipeY;
      container[i].addEventListener('touchstart', function(event) {
          x = event.changedTouches[0].pageX;
          y = event.changedTouches[0].pageY;
          swipeX = true;
          swipeY = true;
          // event.stopPropagation();
          if (expansion) {
              expansion.className = "";
          }
      });
      container[i].addEventListener('touchmove', function(event) {
          X = event.changedTouches[0].pageX;
          Y = event.changedTouches[0].pageY;
          if (swipeX && Math.abs(X - x) - Math.abs(Y - y) > 0) {
              event.stopPropagation();
              if (X - x > 10) {
                  event.preventDefault();
                  this.className = "";
              }
              if (x - X > 10) {
                  event.preventDefault();
                  this.className = "swipeleft";
                  expansion = this;
              }
              swipeY = false;
          }
          if (swipeY && Math.abs(X - x) - Math.abs(Y - y) < 0) {
              swipeX = false;
          }
      });
  }

},
  //转换几分钟前，几天前
    formatMsgTime:function(timespan){
      var dateTime = new Date(timespan); //收到消息时的时间戳
      var year = dateTime.getFullYear();
      var month = dateTime.getMonth() + 1;
      var day = dateTime.getDate();
      var hour = dateTime.getHours();
      var minute = dateTime.getMinutes();
      var second = dateTime.getSeconds();
      // var now = new Date();
      var now_new = Date.parse(new Date());  //转换当前时间时间戳
      var milliseconds = 0;
      var timeSpanStr;
      milliseconds = now_new - timespan;
      if (milliseconds <= 1000 * 60 * 1) {
         timeSpanStr = '刚刚';
      }
      else if(1000 * 60 * 1 < milliseconds && milliseconds <= 1000 * 60 * 60) {
         timeSpanStr = Math.round((milliseconds / (1000 * 60))) + '分钟前';
      }
      else if (1000 * 60 * 60 * 1 < milliseconds && milliseconds <= 1000 * 60 * 60 * 24) {
         timeSpanStr = Math.round(milliseconds / (1000 * 60 * 60)) + '小时前';
      }
      else if (1000 * 60 * 60 * 24 < milliseconds && milliseconds <= 1000 * 60 * 60 * 24 * 30) {
         timeSpanStr = Math.round(milliseconds / (1000 * 60 * 60 * 24)) + '天前';
      }
      else if (1000 * 60 * 60 * 24 * 30 < milliseconds && milliseconds <= 1000 * 60 * 60 * 24 * 30 * 12) {
         timeSpanStr = Math.round(milliseconds / (1000 * 60 * 60 * 24 * 30)) + '月前';
      } else {
         timeSpanStr = year + '-' + month + '-' + day + ' ' + hour + ':' + minute;
      }
         return timeSpanStr;
    },
    times:function(text){
      var date = new Date(text);
      Y = date.getFullYear() + '-';
      M = (date.getMonth()+1 < 10 ? '0'+(date.getMonth()+1) : date.getMonth()+1) + '-';
      D = (date.getDate()< 10 ? '0'+(date.getDate()) : date.getDate())+ ' ';
      h = (date.getHours()< 10 ? '0'+(date.getHours()) : date.getHours())+ ':';
      m = (date.getMinutes()< 10 ? '0'+(date.getMinutes()) : date.getMinutes())+ ':';
      s = (date.getSeconds()< 10 ? '0'+(date.getSeconds()) : date.getSeconds());
    //   console.log(Y+M+D+h+m+s);
       fanst=Y+M+D+h+m+s
       return fanst
    },
    timesCity:function(text){
      var date = new Date(text);
      Y = date.getFullYear() + '-';
      M = (date.getMonth()+1 < 10 ? '0'+(date.getMonth()+1) : date.getMonth()+1) + '-';
      D = (date.getDate()< 10 ? '0'+(date.getDate()) : date.getDate())+ ' ';
      h = (date.getHours()< 10 ? '0'+(date.getHours()) : date.getHours())+ ':';
      m = (date.getMinutes()< 10 ? '0'+(date.getMinutes()) : date.getMinutes())+ ':';
      s = (date.getSeconds()< 10 ? '0'+(date.getSeconds()) : date.getSeconds());
      console.log(Y+M+D+h+m+s);
       fanst=Y+M+D
       return fanst
    },
    //times
addTimer:function(ids,text){
 var list = [],
   interval;

 return function(id,timeStamp){
   if(!interval){
     interval = setInterval(go,1);
   }
   list.push({ele:document.getElementById(id),time:timeStamp});
 }

 function go() {
      for (var i = 0; i < list.length; i++) {
          if(list[i].ele != null || list[i].ele != ''){
              list[i].ele.innerHTML = changeTimeStamp(list[i].time);
              if (!list[i].time)
              list.splice(i--, 1);
            }
        }

 }
 //传入时间戳，得到倒计时
 function changeTimeStamp(timeStamp){
   var distancetime = new Date(timeStamp*1000).getTime() - new Date().getTime();
  //  var distancetime = new Date(timeStamp*1000).getTime();
   if(distancetime > 0){
　　　　　　　　　　　　　　//如果大于0.说明尚未到达截止时间
     var ms = Math.floor(distancetime%1000);
     var sec = Math.floor(distancetime/1000%60);
     var min = Math.floor(distancetime/1000/60%60);
     var hour =Math.floor(distancetime/1000/60/60);
     if(ms<100){
       ms = "0"+ ms;
     }
     if(sec<10){
       sec = "0"+ sec;
     }
     if(min<10){
       min = "0"+ min;
     }
     if(hour<10){
       hour = "0"+ hour;
     }

     return hour + ":" +min + ":" +sec
   }else{
      return "已结束"
   }
 }
}(),
}

})()
