$(function(){
  mui('.mui-scroll-wrapper').scroll({
    deceleration: 0.0003, //flick 减速系数，系数越大，滚动速度越慢，滚动距离越小，默认值0.0006
    indicators: false, //是否显示滚动条
    bounce: true //是否启用回弹
  });
  mui.init({
    pullRefresh : {
      container:"#pullrefresh",
      down : {
        style:"circle",
        height:50,
        range:100,
         offset:0,
         auto: false,
         contentdown : "下拉可以刷新",
         contentover : "释放立即刷新",
         contentrefresh : "正在刷新...",
         callback :loads
      }
    }
  });
  function loads(){
    setTimeout(function () {
            window.location.reload()
            mui('#pullrefresh').pullRefresh().endPulldownToRefresh(); //refresh completed
    }, 500);
  }
  $('.content').css('top','50px')
})
